// src/parents/pages/ParentFees.jsx
// ─────────────────────────────────────────────────────────────────────────────
// Single API:  GET /parent/fees/{studentId}
//   → StudentFeesResponse  (has feeTerms[] + paymentHistory[])
//
// Receipts are constructed from paymentHistory + fee summary data —
// no separate /fee-receipt/* endpoint needed (all had auth bugs + null receiptNumbers).
//
// Tabs:
//   1. Fee Summary  — stat cards + fee breakdown table
//   2. My Receipts  — list from paymentHistory + View modal + Download PDF
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useState } from "react";
import ParentSidebar from "../components/ParentSidebar";
import FeeReceiptTemplate from "../components/FeeReceiptTemplate";
import useParentStudent from "../../common/hooks/useParentStudent";
import API from "../../common/services/api";
import {
  IndianRupee, ReceiptText, RefreshCcw, Eye,
  Printer, Loader2, AlertCircle, CheckCircle, Clock,
} from "lucide-react";

// ── helpers ───────────────────────────────────────────────────────────────────
const fmt = (n) =>
  n != null
    ? new Intl.NumberFormat("en-IN", {
        style: "currency", currency: "INR", minimumFractionDigits: 2,
      }).format(n)
    : "—";

const fmtDate = (s) => {
  if (!s) return "—";
  const d = new Date(s);
  return isNaN(d) ? s : d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
};

// ── shared styles ─────────────────────────────────────────────────────────────
const S = {
  card: {
    background: "#fff", borderRadius: 14,
    boxShadow: "0 1px 8px rgba(0,0,0,0.07)", overflow: "hidden",
  },
  btn: (bg = "#1e3a5f", fg = "#fff") => ({
    background: bg, color: fg, border: "none", borderRadius: 8,
    padding: "8px 16px", cursor: "pointer", fontSize: 13, fontWeight: 600,
    display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap",
  }),
  th: {
    padding: "10px 14px", textAlign: "left", fontWeight: 700,
    color: "#fff", fontSize: 12, background: "#1e3a5f",
  },
  td: { padding: "11px 14px", fontSize: 13, borderBottom: "1px solid #f8fafc" },
};

// ── sub-components ────────────────────────────────────────────────────────────
function Toast({ msg, ok }) {
  return (
    <div style={{
      position: "fixed", top: 20, right: 24,
      background: ok ? "#059669" : "#dc2626",
      color: "#fff", padding: "12px 22px", borderRadius: 10,
      fontWeight: 600, zIndex: 9999,
      boxShadow: "0 4px 20px rgba(0,0,0,0.2)", fontSize: 13,
    }}>{msg}</div>
  );
}

function Stat({ label, value, bg, color, icon }) {
  return (
    <div style={{ background: bg, borderRadius: 12, padding: "16px 20px", flex: 1, minWidth: 140 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
        <span style={{ fontSize: 18 }}>{icon}</span>
        <span style={{ fontSize: 12, color: "#64748b", fontWeight: 600, textTransform: "uppercase" }}>
          {label}
        </span>
      </div>
      <div style={{ fontSize: 22, fontWeight: 900, color }}>{value}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
export default function ParentFees() {
  // studentId from hook — same as old working code
  const { studentId, loading: sidLoading, error: sidError } = useParentStudent();

  const [tab, setTab]         = useState("summary");
  const [toast, setToast]     = useState(null);
  const [loading, setLoading] = useState(false);
  const [feeSummary, setFeeSummary] = useState(null);
  const [modalReceipt, setModalReceipt] = useState(null);

  const notify = (msg, ok = true) => {
    setToast({ msg, ok });
    setTimeout(() => setToast(null), 3500);
  };

  // ── Load fee summary (single API call — same endpoint as old code) ─────────
  const loadSummary = async () => {
    if (!studentId) return;
    setLoading(true);
    try {
      const r = await API.get(`/parent/fees/${studentId}`);
      setFeeSummary(r.data);
    } catch (e) {
      notify(e.response?.data?.message || "Fee summary load nahi hui", false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadSummary(); }, [studentId]);

  // ── Construct receipts from paymentHistory + fee summary ──────────────────
  // paymentHistory.receiptNumber is null → receipts were never generated in backend.
  // We build the receipt object here from available data so FeeReceiptTemplate works.
  const buildReceipts = () => {
    if (!feeSummary?.paymentHistory?.length) return [];
    return feeSummary.paymentHistory.map((ph, idx) => ({
      id:             ph.id,
      receiptNumber:  ph.receiptNumber || `PAY-${ph.id}`,
      issuedAt:       ph.paymentDate,
      issuedOn:       ph.paymentDate,
      amountPaid:     ph.amount,
      // Balance due at time of receipt = remaining after this payment
      // We can only show current remaining; for history it's approximate
      balanceDue:     feeSummary.remainingAmount,
      totalFees:      feeSummary.totalFees,
      paymentMode:    ph.paymentMode,
      transactionRef: ph.transactionId,
      academicYear:   null,
      // Student info from fee summary
      studentName:    feeSummary.studentName,
      admissionNumber: feeSummary.rollNumber?.toString(),
      className:      feeSummary.className,
      section:        null,
      // School info — not in this API response; blank for now
      // (backend team can add schoolName/address to StudentFeesResponse later)
      schoolName:     feeSummary.schoolName     || null,
      schoolAddress:  feeSummary.schoolAddress  || null,
      schoolPhone:    feeSummary.schoolPhone    || null,
      schoolLogoUrl:  feeSummary.schoolLogoUrl  || null,
      // Fee breakdown as line items
      lineItems: (feeSummary.feeTerms || []).map((t) => ({
        feeName: t.termName,
        amount:  t.amount,
        status:  t.status || "PENDING",
      })),
    }));
  };

  const receipts = buildReceipts();

  // Derived totals
  const feeTerms  = feeSummary?.feeTerms  || [];
  const totalFees = feeSummary?.totalFees        ?? 0;
  const totalPaid = feeSummary?.paidAmount        ?? feeSummary?.amountPaid   ?? 0;
  const totalDue  = feeSummary?.remainingAmount   ?? feeSummary?.dueAmount    ?? 0;

  const TABS = [
    { id: "summary",  label: "Fee Summary",  icon: <IndianRupee size={14} /> },
    { id: "receipts", label: "My Receipts",  icon: <ReceiptText size={14} /> },
  ];

  // ─────────────────────────────────────────────────────────────────────────
  return (
    <div style={{
      display: "flex", minHeight: "100vh",
      background: "#f1f5f9", fontFamily: "'Inter',sans-serif",
    }}>
      <ParentSidebar />

      {toast && <Toast {...toast} />}

      <main style={{ flex: 1, padding: "28px 32px", overflowY: "auto" }}>

        {/* Page header */}
        <div style={{ marginBottom: 24 }}>
          <h1 style={{ margin: 0, fontSize: 26, fontWeight: 800, color: "#1e293b" }}>
            Fee Management
          </h1>
          <p style={{ margin: "4px 0 0", color: "#64748b", fontSize: 14 }}>
            Apne bachche ki fees aur receipts yahan dekho
          </p>
        </div>

        {/* Hook loading */}
        {sidLoading && (
          <div style={{ display: "flex", alignItems: "center", gap: 10, color: "#64748b", marginBottom: 20 }}>
            <Loader2 size={18} style={{ animation: "spin 1s linear infinite" }} />
            <span style={{ fontSize: 13 }}>Student details load ho rahi hain...</span>
          </div>
        )}

        {/* Hook error */}
        {!sidLoading && (sidError || !studentId) && (
          <div style={{
            background: "#fef2f2", border: "1px solid #fecaca",
            borderRadius: 10, padding: "14px 18px", marginBottom: 20,
            color: "#dc2626", display: "flex", alignItems: "center", gap: 10,
          }}>
            <AlertCircle size={18} />
            <span style={{ fontSize: 13, fontWeight: 600 }}>
              {sidError || "Student ID nahi mila — logout karke dobara login karein."}
            </span>
          </div>
        )}

        {/* Tabs */}
        <div style={{ display: "flex", gap: 6, marginBottom: 24 }}>
          {TABS.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              style={{
                ...S.btn(tab === t.id ? "#1e3a5f" : "#fff", tab === t.id ? "#fff" : "#475569"),
                boxShadow: tab === t.id
                  ? "0 2px 8px rgba(30,58,95,0.35)"
                  : "0 1px 4px rgba(0,0,0,0.08)",
              }}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* ══════════════ TAB 1 — FEE SUMMARY ══════════════ */}
        {tab === "summary" && (
          <div>
            {/* Stat cards */}
            <div style={{ display: "flex", gap: 14, marginBottom: 20, flexWrap: "wrap" }}>
              <Stat label="Total Fees"  value={fmt(totalFees)} icon="🏷️" bg="#eff6ff" color="#1d4ed8" />
              <Stat label="Amount Paid" value={fmt(totalPaid)} icon="✅" bg="#f0fdf4" color="#059669" />
              <Stat
                label="Balance Due"
                value={fmt(totalDue)}
                icon={totalDue > 0 ? "⚠️" : "✅"}
                bg={totalDue > 0 ? "#fef2f2" : "#f0fdf4"}
                color={totalDue > 0 ? "#dc2626" : "#059669"}
              />
            </div>

            {/* Fee breakdown */}
            <div style={S.card}>
              <div style={{
                padding: "14px 20px", borderBottom: "1px solid #f1f5f9",
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1e293b" }}>
                  Fee Breakdown
                  {feeSummary?.studentName && (
                    <span style={{ marginLeft: 10, fontSize: 13, color: "#64748b", fontWeight: 400 }}>
                      — {feeSummary.studentName} ({feeSummary.className})
                    </span>
                  )}
                </h2>
                <button onClick={loadSummary} disabled={loading}
                  style={{ ...S.btn("#f8fafc", "#64748b"), padding: "6px 12px", fontSize: 12 }}>
                  <RefreshCcw size={12} /> Refresh
                </button>
              </div>

              {loading || sidLoading ? (
                <div style={{ padding: 52, textAlign: "center", color: "#94a3b8" }}>
                  <Loader2 size={22} style={{ animation: "spin 1s linear infinite" }} />
                  <p style={{ marginTop: 10 }}>Loading...</p>
                </div>
              ) : feeTerms.length === 0 ? (
                <div style={{ padding: 52, textAlign: "center", color: "#94a3b8" }}>
                  <IndianRupee size={36} color="#e2e8f0" style={{ marginBottom: 10 }} />
                  <p>Koi fee record nahi mila</p>
                </div>
              ) : (
                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        {["Fee Head", "Amount", "Due Date", "Status"].map((h) => (
                          <th key={h} style={S.th}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {feeTerms.map((item) => {
                        const s = (item.status || "PENDING").toUpperCase();
                        const statusBg  = { PAID: "#dcfce7", PARTIAL: "#fef9c3", PENDING: "#fee2e2", DUE: "#fee2e2" }[s] ?? "#f1f5f9";
                        const statusClr = { PAID: "#059669", PARTIAL: "#d97706", PENDING: "#dc2626", DUE: "#dc2626" }[s] ?? "#475569";
                        return (
                          <tr key={item.id}
                            onMouseEnter={(e) => e.currentTarget.style.background = "#f8fafc"}
                            onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
                          >
                            <td style={{ ...S.td, fontWeight: 600, color: "#1e293b" }}>
                              {item.termName || item.feeName || "—"}
                            </td>
                            <td style={{ ...S.td, fontWeight: 600 }}>{fmt(item.amount)}</td>
                            <td style={{ ...S.td, color: "#64748b" }}>
                              {fmtDate(item.dueDate)}
                            </td>
                            <td style={S.td}>
                              <span style={{
                                background: statusBg, color: statusClr,
                                borderRadius: 6, padding: "3px 10px",
                                fontWeight: 700, fontSize: 12,
                              }}>
                                {item.status || "PENDING"}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    {/* Totals footer */}
                    <tfoot>
                      <tr style={{ background: "#1e3a5f" }}>
                        <td style={{ ...S.td, fontWeight: 800, color: "#fff", borderBottom: "none" }}>TOTAL</td>
                        <td style={{ ...S.td, fontWeight: 800, color: "#fff", borderBottom: "none" }}>{fmt(totalFees)}</td>
                        <td style={{ ...S.td, borderBottom: "none" }} />
                        <td style={{ ...S.td, borderBottom: "none" }}>
                          <span style={{
                            background: totalDue > 0 ? "#dc2626" : "#059669",
                            color: "#fff", borderRadius: 6, padding: "3px 10px",
                            fontWeight: 700, fontSize: 12,
                          }}>
                            {totalDue > 0 ? `Due: ${fmt(totalDue)}` : "CLEARED"}
                          </span>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>

            {/* Payment History (read-only) */}
            {feeSummary?.paymentHistory?.length > 0 && (
              <div style={{ ...S.card, marginTop: 20 }}>
                <div style={{ padding: "14px 20px", borderBottom: "1px solid #f1f5f9" }}>
                  <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1e293b" }}>
                    Payment History
                  </h2>
                </div>
                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        {["Date", "Amount", "Mode", "Ref / Transaction ID", "Status"].map((h) => (
                          <th key={h} style={S.th}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {feeSummary.paymentHistory.map((ph) => {
                        const s = (ph.status || "").toUpperCase();
                        const bg  = { SUCCESS: "#dcfce7", PENDING_VERIFICATION: "#fef9c3", REJECTED: "#fee2e2" }[s] ?? "#f1f5f9";
                        const clr = { SUCCESS: "#059669", PENDING_VERIFICATION: "#d97706", REJECTED: "#dc2626" }[s] ?? "#475569";
                        return (
                          <tr key={ph.id}
                            onMouseEnter={(e) => e.currentTarget.style.background = "#f8fafc"}
                            onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
                          >
                            <td style={{ ...S.td, color: "#475569" }}>{fmtDate(ph.paymentDate)}</td>
                            <td style={{ ...S.td, fontWeight: 700, color: "#059669" }}>{fmt(ph.amount)}</td>
                            <td style={S.td}>
                              <span style={{
                                background: "#eff6ff", color: "#1d4ed8",
                                borderRadius: 6, padding: "2px 8px",
                                fontWeight: 600, fontSize: 12,
                              }}>
                                {ph.paymentMode || "—"}
                              </span>
                            </td>
                            <td style={{ ...S.td, color: "#64748b", fontSize: 12 }}>
                              {ph.transactionId || "—"}
                            </td>
                            <td style={S.td}>
                              <span style={{
                                background: bg, color: clr,
                                borderRadius: 6, padding: "3px 10px",
                                fontWeight: 700, fontSize: 12,
                                display: "inline-flex", alignItems: "center", gap: 4,
                              }}>
                                {s === "SUCCESS" && <CheckCircle size={10} />}
                                {s === "PENDING_VERIFICATION" && <Clock size={10} />}
                                {ph.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Quick link to receipts */}
            {!loading && totalPaid > 0 && (
              <div style={{
                marginTop: 16, background: "#eff6ff", border: "1px solid #bfdbfe",
                borderRadius: 10, padding: "12px 18px",
                display: "flex", alignItems: "center", justifyContent: "space-between",
              }}>
                <span style={{ fontSize: 13, color: "#1d4ed8" }}>
                  💡 Apni payment receipts dekhne/download karne ke liye "My Receipts" tab pe jao
                </span>
                <button onClick={() => setTab("receipts")}
                  style={{ ...S.btn("#1d4ed8"), padding: "6px 14px", fontSize: 12 }}>
                  View Receipts →
                </button>
              </div>
            )}
          </div>
        )}

        {/* ══════════════ TAB 2 — RECEIPTS ══════════════ */}
        {tab === "receipts" && (
          <div>
            <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
              <button onClick={loadSummary} disabled={loading}
                style={{ ...S.btn("#f8fafc", "#64748b"), padding: "7px 14px", fontSize: 12 }}>
                <RefreshCcw size={12} /> {loading ? "Loading..." : "Refresh"}
              </button>
            </div>

            {loading || sidLoading ? (
              <div style={{ ...S.card, padding: 52, textAlign: "center", color: "#94a3b8" }}>
                <Loader2 size={22} style={{ animation: "spin 1s linear infinite" }} />
                <p style={{ marginTop: 10 }}>Receipts load ho rahi hain...</p>
              </div>
            ) : receipts.length === 0 ? (
              <div style={{ ...S.card, padding: 52, textAlign: "center", color: "#94a3b8" }}>
                <ReceiptText size={40} color="#e2e8f0" style={{ marginBottom: 12 }} />
                <p style={{ margin: 0, fontSize: 14, fontWeight: 600 }}>Koi payment nahi mili abhi</p>
                <p style={{ margin: "6px 0 0", fontSize: 12 }}>
                  Payment ke baad receipt yahan dikhegi
                </p>
              </div>
            ) : (
              <div style={S.card}>
                <div style={{
                  padding: "14px 20px", borderBottom: "1px solid #f1f5f9",
                  display: "flex", justifyContent: "space-between", alignItems: "center",
                }}>
                  <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1e293b" }}>
                    Payment Receipts
                    <span style={{ marginLeft: 8, fontSize: 13, color: "#64748b", fontWeight: 400 }}>
                      ({receipts.length} receipt{receipts.length > 1 ? "s" : ""})
                    </span>
                  </h2>
                </div>

                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        {["Receipt No.", "Date", "Student", "Amount Paid", "Payment Mode", "Actions"].map((h) => (
                          <th key={h} style={S.th}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {receipts.map((rc, i) => (
                        <tr key={rc.id || i}
                          onMouseEnter={(e) => e.currentTarget.style.background = "#f8fafc"}
                          onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}
                        >
                          {/* Receipt number */}
                          <td style={{ ...S.td, fontWeight: 700, color: "#1e3a5f" }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                              <ReceiptText size={13} color="#1e3a5f" />
                              {rc.receiptNumber}
                            </div>
                          </td>

                          {/* Date */}
                          <td style={{ ...S.td, color: "#475569" }}>
                            {fmtDate(rc.issuedAt || rc.issuedOn)}
                          </td>

                          {/* Student */}
                          <td style={S.td}>
                            <div style={{ fontWeight: 600, color: "#1e293b" }}>{rc.studentName || "—"}</div>
                            <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 1 }}>
                              {rc.className}{rc.admissionNumber ? ` · Roll ${rc.admissionNumber}` : ""}
                            </div>
                          </td>

                          {/* Amount */}
                          <td style={{ ...S.td, fontWeight: 700, color: "#059669" }}>
                            {fmt(rc.amountPaid)}
                          </td>

                          {/* Mode */}
                          <td style={S.td}>
                            <span style={{
                              background: "#eff6ff", color: "#1d4ed8",
                              borderRadius: 6, padding: "2px 8px",
                              fontWeight: 600, fontSize: 12,
                            }}>
                              {rc.paymentMode || "—"}
                            </span>
                          </td>

                          {/* Actions */}
                          <td style={S.td}>
                            <div style={{ display: "flex", gap: 6 }}>
                              <button
                                onClick={() => setModalReceipt(rc)}
                                title="View receipt"
                                style={{
                                  background: "#eff6ff", color: "#1d4ed8",
                                  border: "none", borderRadius: 6,
                                  padding: "5px 12px", cursor: "pointer",
                                  display: "flex", alignItems: "center", gap: 4,
                                  fontSize: 12, fontWeight: 600,
                                }}
                              >
                                <Eye size={12} /> View
                              </button>
                              <button
                                onClick={() => setModalReceipt(rc)}
                                title="Download PDF (from modal)"
                                style={{
                                  background: "#f0fdf4", color: "#059669",
                                  border: "none", borderRadius: 6,
                                  padding: "5px 12px", cursor: "pointer",
                                  display: "flex", alignItems: "center", gap: 4,
                                  fontSize: 12, fontWeight: 600,
                                }}
                              >
                                <Printer size={12} /> Print / PDF
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Note */}
                <div style={{
                  padding: "10px 20px", background: "#f8fafc",
                  borderTop: "1px solid #f1f5f9", fontSize: 12, color: "#64748b",
                }}>
                  💡 <strong>View</strong> se receipt modal mein open hogi &nbsp;|&nbsp;
                  Modal mein <strong>Download PDF</strong> button se save karo &nbsp;|&nbsp;
                  <strong>Print</strong> button se printer dialog aayega
                </div>
              </div>
            )}
          </div>
        )}

      </main>

      {/* ── Receipt Modal ── */}
      {modalReceipt && (
        <FeeReceiptTemplate
          receipt={modalReceipt}
          onClose={() => setModalReceipt(null)}
        />
      )}

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}