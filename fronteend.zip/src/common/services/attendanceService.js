/**
 * attendanceService.js
 * Central service for ALL attendance-related API calls.
 * Uses the shared `API` axios instance (auto JWT + refresh).
 */
import API from "./api";

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS — ERROR DETECTION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Returns true if the error is a "attendance already marked" 400 error.
 */
export const isAlreadyMarkedError = (error) => {
  const msg =
    error?.response?.data?.message ||
    error?.response?.data ||
    "";
  return (
    error?.response?.status === 400 &&
    typeof msg === "string" &&
    (msg.toLowerCase().includes("already marked") ||
      msg.toLowerCase().includes("already been marked") ||
      msg.toLowerCase().includes("ek period"))
  );
};

/**
 * Extracts the human-readable message from an already-marked error.
 */
export const getAlreadyMarkedMessage = (error) => {
  const msg =
    error?.response?.data?.message ||
    error?.response?.data ||
    "";
  return typeof msg === "string" ? msg : null;
};

// ─────────────────────────────────────────────────────────────────────────────
// TEACHER — MARK ATTENDANCE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Mark attendance for all students in a classroom (one subject, one period).
 * POST /attendance/{classroomId}/attendance
 * @param {number} classroomId
 * @param {{ subjectId, date, periodNumber, students: [{studentId, status}] }} payload
 */
export const markClassAttendance = (classroomId, payload) =>
  API.post(`/attendance/${classroomId}/attendance`, payload);

/**
 * Mark attendance for a SINGLE student.
 * POST /attendance/{classroomId}/student/{studentId}
 * @param {number} classroomId
 * @param {number} studentId
 * @param {{ subjectId, date, periodNumber, status, remarks? }} payload
 */
export const markSingleStudentAttendance = (classroomId, studentId, payload) =>
  API.post(`/attendance/${classroomId}/student/${studentId}`, payload);

// ─────────────────────────────────────────────────────────────────────────────
// STUDENT / PARENT — VIEW ATTENDANCE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Daily attendance for a student on a specific date.
 * GET /attendance/{studentId}?type=DAILY&date=YYYY-MM-DD
 */
export const getDailyAttendance = (studentId, date) =>
  API.get(`/attendance/${studentId}`, { params: { type: "DAILY", date } });

/**
 * Lecture-wise attendance for a student on a specific date.
 * GET /attendance/{studentId}?type=LECTURE&date=YYYY-MM-DD
 */
export const getLectureAttendance = (studentId, date) =>
  API.get(`/attendance/${studentId}`, { params: { type: "LECTURE", date } });

/**
 * Monthly attendance summary.
 * GET /attendance/{studentId}?type=MONTHLY&year=YYYY&month=M
 */
export const getMonthlyAttendance = (studentId, year, month) =>
  API.get(`/attendance/${studentId}`, { params: { type: "MONTHLY", year, month } });
// /**
//  * attendanceService.js
//  * Central service for ALL attendance-related API calls.
//  * Uses the shared `API` axios instance (auto JWT + refresh).
//  */
// import API from "./api";

// // ─────────────────────────────────────────────────────────────────────────────
// // TEACHER — MARK ATTENDANCE
// // ─────────────────────────────────────────────────────────────────────────────

// /**
//  * Mark attendance for all students in a classroom (one subject, one period).
//  * POST /attendance/{classroomId}/attendance
//  * @param {number} classroomId
//  * @param {{ subjectId, date, periodNumber, students: [{studentId, status}] }} payload
//  */
// export const markClassAttendance = (classroomId, payload) =>
//   API.post(`/attendance/${classroomId}/attendance`, payload);

// /**
//  * Mark attendance for a SINGLE student.
//  * POST /attendance/{classroomId}/student/{studentId}
//  * @param {number} classroomId
//  * @param {number} studentId
//  * @param {{ subjectId, date, periodNumber, status, remarks? }} payload
//  */
// export const markSingleStudentAttendance = (classroomId, studentId, payload) =>
//   API.post(`/attendance/${classroomId}/student/${studentId}`, payload);

// // ─────────────────────────────────────────────────────────────────────────────
// // STUDENT / PARENT — VIEW ATTENDANCE
// // ─────────────────────────────────────────────────────────────────────────────

// /**
//  * Daily attendance for a student on a specific date.
//  * GET /attendance/{studentId}?type=DAILY&date=YYYY-MM-DD
//  */
// export const getDailyAttendance = (studentId, date) =>
//   API.get(`/attendance/${studentId}`, { params: { type: "DAILY", date } });

// /**
//  * Lecture-wise attendance for a student on a specific date.
//  * GET /attendance/{studentId}?type=LECTURE&date=YYYY-MM-DD
//  */
// export const getLectureAttendance = (studentId, date) =>
//   API.get(`/attendance/${studentId}`, { params: { type: "LECTURE", date } });

// /**
//  * Monthly attendance summary.
//  * GET /attendance/{studentId}?type=MONTHLY&year=YYYY&month=M
//  */
// export const getMonthlyAttendance = (studentId, year, month) =>
//   API.get(`/attendance/${studentId}`, { params: { type: "MONTHLY", year, month } });
